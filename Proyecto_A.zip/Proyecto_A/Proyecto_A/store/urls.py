from django.shortcuts import render
from django.urls import path

from . import views


urlpatterns = [
    path("", views.index, name="index"),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('products/all/', views.all_products, name='all_products'),
    path('cart/', views.cart_detail, name='cart_detail'),
    path('cart/add/id=<int:product_id>-quantity=<int:quantity>/', views.add_to_cart, name='add_to_cart'),
    path('cart/subtract/id=<int:product_id>-quantity=<int:quantity>/', views.subtract_from_cart, name='subtract_from_cart'),
    path('cart/remove/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/clean/', views.clean_cart, name='clean_cart'),
    path('select-delivery-shop/', views.pickup, name='pickup'),
    path('change-delivery-shop<int:DS>/', views.change_shop, name='change_shop'),
    path('delivery-info/', views.delivery, name='delivery'),
    path('delivery-info/confirm/', views.confirm_delivery, name='confirm_delivery'),
    path('payment/', views.payment, name='payment'),
    path('payment/process/', views.process_payment, name='proccess_payment'),
    path('profile/my-orders/', views.my_orders, name='my_orders'),

]

