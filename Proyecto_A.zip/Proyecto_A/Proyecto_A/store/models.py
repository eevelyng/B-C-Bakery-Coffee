from django.db import models
from django.contrib.auth.models import User
import uuid

# Create your models here.

#Modelo category con campos name, description e image_url 
class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    image_url = models.URLField(blank=True)
    def __str__(self):
        return self.name

#Modelo product con campos category, name, description, price e image_url
class Product(models.Model):
    category = models.ForeignKey('Category', on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image_url = models.URLField(blank=True)

    def __str__(self):
        return self.name

#Modelo store con campos name, address, city, state, zip_code, phone, email y status
class Store(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zip_code = models.CharField(max_length=10)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    status = models.CharField(max_length=100)
    def __str__(self):
        return self.name

#Modelo order con campos user(llave foranea a la tabla users.id), total_amount, collect_date, collect_time, collect_code, pickup_store(llave foranea a la tabla store.id), status y created_at
class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    collect_date = models.DateField(null=True, default="null")
    collect_time = models.TimeField(null=True, default="null")
    collect_code = models.CharField(max_length=100, unique=True, editable=False, default=uuid.uuid4)
    pickup_store = models.ForeignKey('Store', on_delete=models.CASCADE, default=1)
    status = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

#Modelo Collector con campos names, father_last_name, mother_last_name, email, phone y order(llave foranea a la tabla order.id)
class Collector(models.Model):
    names = models.CharField(max_length=100)
    father_last_name = models.CharField(max_length=100)
    mother_last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    order = models.ForeignKey('Order', on_delete=models.CASCADE)
    def __str__(self):
        return self.name

#Modelo OrderItem con campos order(llave foranea a la tabla order.id), product(llave foranea a la tabla product.id), quantity y subtotal
class OrderItem(models.Model):
    order = models.ForeignKey('Order', on_delete=models.CASCADE)
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    quantity = models.IntegerField()
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return self.name

#Modelo Payment con campos payment_method, card_number, cvv, expiry_date, name_on_card, user(llave foranea a la tabla users.id) y created_at
class Payment(models.Model):

    PAYMENT_METHOD_CHOICES = [
        ('paypal', 'PayPal'),
        ('credit_card', 'Credit Card'),
    ]

    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    card_number = models.CharField(max_length=16, blank=True, null=True)
    cvv = models.CharField(max_length=4, blank=True, null=True)
    expiry_date = models.CharField(max_length=7, blank=True, null=True)  
    name_on_card = models.CharField(max_length=100, blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True, default=None)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.payment_method} - {self.created_at.strftime('%Y-%m-%d')}"

        