import uuid
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from .models import Collector, Order, OrderItem, Payment, Product, Store
from .models import Category
from django.contrib.auth.decorators import login_required


# Muestra la página principal con todos los productos
def index(request):
    products = Product.objects.all()
    categories = Category.objects.all()
    
    
    return render(request, "store/index.html", {'products': products, 'categories': categories} )

# Muestra todos los productos
def all_products(request):
    products = Product.objects.all()
    return render(request, 'store/products.html', {'products': products})


# Muestra el detalle de un producto
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    quantity = 1
    return render(request, 'store/product_detail.html', {'product': product, 'quantity': quantity})

# Muestra el contenido del carrito con los productos y el total
def cart_detail(request):

    #verificar si hay productos en el carrito
    error_message = request.GET.get('error', None)
    #si hay un mensaje de error de que no hay productos en el carrito, guardarlo en el contexto para ser mostrado
    if error_message:
        context = {'error_message': error_message}
    else:
        context = {}
    #obtener los productos del carrito
    cart = request.session.get('cart', {})
    products = []
    total = 0
    quantity = 0
    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        products.append({
            'product': product,
            'quantity': quantity,
            'subtotal': product.price * quantity,
        })
        total += product.price * quantity

    return render(request, 'store/cart_detail.html', {'products': products, 'total': total, 'quantity': quantity, 'context': context})

# Agrega un producto al carrito
def add_to_cart(request, product_id, quantity):
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.get('cart', {})
    # Agrega o incrementa la cantidad del producto en el carrito
    if str(product_id) in cart:
        cart[str(product_id)] += quantity
    else:
        cart[str(product_id)] = quantity

    request.session['cart'] = cart  # Guarda el carrito en la sesión
    request.session.modified = True  # Marca la sesión como modificada
    return redirect('cart_detail')

# Resta un producto al carrito
def subtract_from_cart(request, product_id, quantity):
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.get('cart', {})
    # Resta o decrementa la cantidad del producto en el carrito
    if str(product_id) in cart:
        cart[str(product_id)] -= quantity
        if cart[str(product_id)] <= 0:
            del cart[str(product_id)]

    request.session['cart'] = cart  # Guarda el carrito en la sesión
    request.session.modified = True  # Marca la sesión como modificada
    return redirect('cart_detail')  # Redirige a la vista del carrito de compras

# Elimina un producto del carrito
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        del cart[str(product_id)]

    request.session['cart'] = cart  # Guarda el carrito actualizado en la sesión
    request.session.modified = True
    return redirect('cart_detail')

#Vacia el carrito por completo
def clean_cart(request):
    cart = request.session.get('cart', {})
    cart.clear()
    request.session['cart'] = cart  # Guarda el carrito actualizado en la sesión
    request.session.modified = True
    return redirect('cart_detail')

@login_required
# Muestra la página de recogida del producto
def pickup(request):
    #verificar que el usuario este autenticado sino es asi redirigir a la pagina de login con error
    if not request.user.is_authenticated:
        url = reverse('login') + '?error=Debes%20iniciar%20sesión%20para%20continuar%20con%20tu%20compra' 
        return HttpResponseRedirect(url)
    else:
        #verificar si hay productos en el carrito
        if not request.session.get('cart', {}):
            url = reverse('cart_detail') + '?error=No%20hay%20productos%20en%20el%20carrito' 
            return HttpResponseRedirect(url)
        else:
            #obtener las tiendas de recogida
            stores = Store.objects.all()
            return render(request, 'store/pickup.html', {'stores': stores})
    

# Cambia la tienda de recogida
def change_shop(request, DS):
    request.session['DS'] = DS
    request.session.modified = True
    return redirect('delivery')

@login_required
# Muestra la página de la entrega del producto
def delivery(request):
    #obtener los productos del carrito
    cart = request.session.get('cart', {})
    products = []
    total = 0
    quantity = 0
    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        products.append({
            'product': product,
            'quantity': quantity,
            'subtotal': product.price * quantity,
        })
        total += product.price * quantity
        #obtener la tienda de recogida
        ds = Store.objects.get(id=request.session.get('DS', {}))
    return render(request, 'store/delivery.html', {'products': products, 'total': total, 'quantity': quantity, 'DS': ds})

@login_required
#guarda la información del formulario enviado 
def confirm_delivery(request):
    if request.method == 'POST':
        #recupera los datos del formulario enviado
        collecter_name = request.POST.get('collecter_name')
        collecter_father_last_name = request.POST.get('collecter_father_last_name')
        collecter_mother_last_name = request.POST.get('collecter_mother_last_name')
        collecter_email = request.POST.get('collecter_email')
        collecter_phone = request.POST.get('collecter_phone')
        collect_date = request.POST.get('collect_date')
        collect_time = request.POST.get('collect_time')
        #recupera la tienda de la sesion
        collect_store = Store.objects.get(id=request.session.get('DS', {}))
        #guarda los datos de la orden en la base de datos
        order = Order(
            user = request.user,
            total_amount = 0,
            collect_date = collect_date,
            collect_time = collect_time,
            collect_code = uuid.uuid4().hex[:8],
            pickup_store = collect_store,
            status = 'Solicitado',
        )

        #guardar la orden en la base de datos y almacenar su ide para usarla en el registro del recolector

        order.save()

        #guardar datos del recolector en la base de datos
        collector = Collector(
            names = collecter_name,
            father_last_name = collecter_father_last_name,
            mother_last_name = collecter_mother_last_name,
            email = collecter_email,
            phone = collecter_phone,
            order = order,
        )

        collector.save()

        #recupera los productos de la sesion y se almacenan en la tabla intermedia de orderitems

        cart = request.session.get('cart', {})
        total = 0
        for product_id, quantity in cart.items():
            product = Product.objects.get(id=product_id)
            order_item = OrderItem(
                order = order,
                product = product,
                quantity = quantity,
                subtotal = product.price * quantity,
            )
            order_item.save()
            total += product.price * quantity

        #actualizar el total de la orden
        order.total_amount = total
        order.save()
        return redirect('payment')
    else:
        return redirect('delivery')
    
@login_required
def payment(request):
     #obtener los productos del carrito
    cart = request.session.get('cart', {})
    products = []
    total = 0
    quantity = 0
    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        products.append({
            'product': product,
            'quantity': quantity,
            'subtotal': product.price * quantity,
        })
        total += product.price * quantity
        #obtener la tienda de recogida
        ds = Store.objects.get(id=request.session.get('DS', {}))
    return render(request, 'store/payment.html', {'products': products, 'total': total, 'quantity': quantity, 'DS': ds})

@login_required
def process_payment(request):
    
    card_number = request.POST.get('cardNumber')
    cvv = request.POST.get('cvv')
    expire_date = request.POST.get('expireDate')
    card_name = request.POST.get('nameOnCard')

    #guardar los datos de la tarjeta en la base de datos
    payment = Payment(
        payment_method = 'credit_card',
        card_number = card_number,
        cvv = cvv,
        expiry_date = expire_date,
        name_on_card = card_name,
        user = request.user,
    )
    payment.save()
    
    #actualizar el estado de la orden
    order = Order.objects.filter(user=request.user).last()
    order.status = 'Pagado'
    order.save()
    #limpiar el carrito
    cart = request.session.get('cart', {})
    cart.clear()
    request.session['cart'] = cart  # Guarda el carrito actualizado en la sesión
    request.session.modified = True

   
    return render(request, 'store/payment_success.html')

@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'store/my_orders.html', {'orders': orders})
