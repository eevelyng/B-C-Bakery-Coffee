
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UserRegisterForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView

@login_required
def profile(request):
    return render(request, 'accounts/profile.html')

class CustomLoginView(LoginView):
    template_name = 'accounts/login.html' 
    def get_context_data(self, **kwargs): 
        context = super().get_context_data(**kwargs) 
        context['error_message'] = self.request.GET.get('error', None) 
        return context

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            messages.success(request, f'¡Cuenta creada para {username}! Ahora puedes iniciar sesión.')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'accounts/register.html', {'form': form})
